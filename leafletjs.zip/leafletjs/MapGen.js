/**
 * Created by Zohaib Ahmad on 9/15/2015.
 */

/*  ALL THE DATA FROM DATABASE WILL SAVE IN THIS OBJECT
 IT HAS 3 LEVELS
 LEVEL 0 :   NAME,   VALUE,  BOUND,  CTSC
 |
 LEVEL 1 :                           NAME,   VALUE,  BOUND,  SCHOOL
 |
 LEVEL 2 :                                                   NAME, VALUE, LAT, LNG
 */
var all_dist = [];

/*  SIMPLE STACK CONTAINS HISTORY OF MAP LEVELS */
user_history = [];

/*  NO OF PARTS OF LEGEND, THIS WILL USE IN GETTING COLOR, RANGE, RADIUS OF CIRCLE  */
var parts = 5;

/*  COLORS FOR LEGENDS IT MUST BE EQUAL TO THE VALUE OF PARTS   */
var color = ["#DF0101","#BFFF00","#FFFF00","#00FF40","#0404B4"];

/*
 map     :   MAIN MAP OBJECT
 popup   :   MAIN POPUP OBJECT, USED WHEN MOUSE WILL BE ON THE CIRCLE
 layer   :   MAIN MAP CIRCLE LAYER, USER TO DRAW CIRCLES
 legend  :   MAIN OBJECT FOR LEGEND
 button  :   OBJECT FOR BACK OF THE THE MAP
 */
var map = null, popup = null, layer = null, legend = null, button = null;

/*  DEFINING MIN, MAX VALUES FOR EACH LEVEL
 POPULATING THE all_dist OBJECT
 */
var dist_min = 99999, dist_max = 0;
db_dist.forEach(function(e)
{
    all_dist.push({name: e[0], value: e[1], bound: "", ctsc: []});

    if (dist_max < e[1])
        dist_max = e[1];
    if (dist_min > e[1])
        dist_min = e[1];
});
//show(all_dist, "all_dist");

var ctsc_min = 99999, ctsc_max = 0;
db_ctsc.forEach(function(e)
{
    all_dist.forEach(function(ex)
    {
        if(ex.name === e[1])
        {
            ex.ctsc.push({name: e[0], value: e[2], bound: "", school: []});

            if (ctsc_max < e[2])
                ctsc_max = e[2];
            if (ctsc_min > e[2])
                ctsc_min = e[2];
        }
    });
});
//show(all_dist, "all_dist");

var school_min = 99999, school_max = 0;
db_schl.forEach(function(e)
{
    all_dist.forEach(function (ex)
    {
        ex.ctsc.forEach(function(ctsc)
        {
            if(ctsc.name === e[4])
            {
                ctsc.school.push({name: e[0], lat: e[1], lng: e[2], value: e[3]});

                if (school_max < e[3])
                    school_max = e[3];
                if (school_min > e[3])
                    school_min = e[3];
            }
        });
    });
});
//show(all_dist, "all_dist");

/*  CALCULATE THE CENTER OF CTSC AND DISTRICT BY GETTING AVERAGE OF SCHOOL LAT LNG  */
all_dist.forEach(function (e)
{
    var ctsc_center = [];
    e.ctsc.forEach(function(s)
    {
        var ctsc_latlng = [];
        s.school.forEach(function(e)
        {
            ctsc_latlng.push([e.lat, e.lng]);
        });

        s.bound = new L.LatLngBounds(ctsc_latlng);
        ctsc_center.push(s.bound.getCenter());
    });

    e.bound = new L.LatLngBounds(ctsc_center);
});
//show(all_dist, "all_dist");

//console.log(dist_min + ", " + dist_max + ", " + ctsc_min + ", " + ctsc_max + ", " + school_min + ", " + school_max);

///////////////////////////////////
/*  INITIATE THE MAP ON THE PAGE    */
Init_Map("google");

/*  DRAW THE HOME BUTTON ON THE PAGE    */
Draw_Home_Button();

/*  Draw_Circle() is a recursive function to draw the circles on the page, it calls itself according to level   */
Draw_Circle("", 0);
///////////////////////////////////

function Init_Map(map_type)
{
    map = L.map('map', { center: [31.7150, 73.9850], zoom: 8, maxZoom: 25 });

    if(map_type == "google")
    {
        var googleLayer = new L.Google('ROAD');
        map.addLayer(googleLayer);
    }
    else
    {
        L.tileLayer('http://{s}.mqcdn.com/tiles/1.0.0/map/{z}/{x}/{y}.png', {subdomains: ["otile1","otile2","otile3","otile4"]}).addTo(map);
    }

    //popup = L.popup();
}

function Draw_Circle(data, level)
{
    var arr = [];

    if(layer !== null)
        map.removeLayer(layer);

    layer = new L.layerGroup();

    switch (level)
    {
        case 0:     // all districts
            all_dist.forEach(function(e)
            {
                arr.push(e.bound.getCenter());
                var c = Circle(e.bound.getCenter(), e.value, dist_min, dist_max);

                var popup_text = e.name + ", " + e.value;

                c.on('click', function ()
                {
                    Draw_Circle(e.ctsc, 1);
                });

                c.on('mouseover', function ()
                {
                    popup = L.popup({offset: [0, -10]})
                        .setLatLng(e.bound.getCenter())
                        .setContent(popup_text)
                        .openOn(map);
                });

                c.addTo(layer);
            });

            Draw_Legend(dist_min, dist_max, parts);
            break;

        case 1:     // ctsc of disctrict
            data.forEach(function(e)
            {
                arr.push(e.bound.getCenter());
                var c = Circle(e.bound.getCenter(), e.value, ctsc_min, ctsc_max);

                var popup_text = e.name + ", " + e.value;

                c.on('click', function ()
                {
                    Draw_Circle(e.school, 2);
                });

                c.on('mouseover', function ()
                {
                    var p = L.popup({offset: [0, -10]})
                        .setLatLng(e.bound.getCenter())
                        .setContent(popup_text)
                        .openOn(map);
                });

                c.addTo(layer);
            });

            Draw_Legend(ctsc_min, ctsc_max, parts);
            break;

        case 2:     // school of ctsc
            data.forEach(function(e)
            {
                arr.push([e.lat, e.lng]);
                var c = Circle([e.lat, e.lng], e.value, school_min, school_max);

                var popup_text = e.name + ", " + e.value;

                c.on('mouseover', function ()
                {
                    this.bindPopup(popup_text).openPopup();
                });

                c.addTo(layer);
            });

            Draw_Legend(school_min, school_max, parts);
            break;
    }

    user_history.push({data: data, level: level});

    Draw_Button();

    user_history.forEach(function(e)
    {
        console.log("Data:"+ e.data + ", level:" + e.level);
    });
    console.log("------------------");
    map.fitBounds(arr);
    map.addLayer(layer);
}

function Circle(center, value, min, max)
{
    return  L.circleMarker(center,
        {
            radius: Get_Radius(Get_Range(min, max, parts), value, parts),
            fillColor: Get_Color(Get_Range(min, max, parts), value, parts),
            color: "#000",
            weight: 1,
            opacity: 1,
            fillOpacity: 0.5
        });
}

function Draw_Legend(min, max, parts)
{
    if(legend !== null)
        map.removeControl(legend);

    var range = Get_Range(min, max, parts);

    legend = L.control({position: 'bottomright'});

    legend.onAdd = function ()
    {
        var div = L.DomUtil.create('div', 'info legend'),
            grades = range,
            labels = [],
            from, to;

        for (var i = 0; i < grades.length; i++)
        {
            from = grades[i];
            to = grades[i + 1];

            labels.push(
                '<i style="background:' + color[i] + '"></i> ' +
                from + (to ? '&ndash;' + to : '+'));
        }

        div.innerHTML = labels.join('<br>');

        return div;
    };

    legend.addTo(map);
}

function Draw_Home_Button()
{
    L.easyButton('<span> H </span>', function()
    {
        if(user_history.length > 1)
        {
            Draw_Circle("", 0);
        }
    }).addTo(map);
}

function Draw_Button()
{
    if(button !== null)
        map.removeControl(button);

    button = L.easyButton('<span> < </span>', function()
    {
        if(user_history.length > 1)
        {
            Draw_Circle(user_history[user_history.length-2].data, user_history[user_history.length-2].level);
            user_history.pop();
            user_history.pop();
        }
    }).addTo(map);
}

function Get_Color(range, value, parts)
{
    for(var i=0; i<=parts; i++)
    {
        if((i+1) != parts)
        {
            var mi = range[i];
            var mx = range[i+1];

            var v = ((value - mi)*(value-mx));

            if(v <= 0)
            {
                //console.log("min:" + mi + ", max:" + mx + ", value:" + value + ", check :" + v + ", color:" + color[i]);
                return color[i];
            }
        }
        else
        {
            //console.log("max value , color:" + color[i]);
            return color[i];
        }
    }
}

function Get_Radius(range, value, parts)
{
    var default_radius = 5;

    for(var i=0; i<=parts; i++)
    {
        if(i != parts)
        {
            var mi = range[i];
            var mx = range[i+1];

            var v = ((value - mi)*(value-mx));

            if(v <= 0)
            {
                //console.log("min:" + mi + ", max:" + mx + ", value:" + value + ", check :" + v + ", radius:" + (i+1)*default_radius);
                return (i+1+default_radius);
            }
        }
        else if((i+1) == parts)
        {
            //console.log("max value , radius:" + (i+1)*default_radius);
            return (i+1+default_radius);
        }
    }
}

function Get_Range(min, max, parts)
{
    var range = [min];
    for(var i=1; i<=parts; i++)
        range.push(min += parseInt((max - min)/parts));

    if(range[range.length-1] != max)
        range[range.length-1] = max;

    return range;
}

function show(data, msg)
{
    console.log("------------" + msg + "------------");
    data.forEach(function(e)
    {
        console.log(e);
    });
    console.log("------------" + "END" + "------------");
}